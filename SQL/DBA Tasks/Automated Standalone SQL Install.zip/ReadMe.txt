Blog:		http://joeydantoni.com/2014/03/31/building-perfect-sql-servers-every-time/
Download:	https://www.dropbox.com/sh/psud36aia9x56ho/xDACi6YwRy